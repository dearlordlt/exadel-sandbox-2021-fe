export const educationalPrograms = ['All', '.NET,JS,BA: 10-11.2021', 'Java,JS,BA: 6-7.2021', 'PHP,JS: 2-3.2021'];
export const statuses = {
  search: [
    'All',
    'the application is accepted',
    'refusal by the level of English',
    'refusal by location',
    "recruiter's interview is scheduled",
    'interview of the interviewer is scheduled',
    'questionable',
    'failure on the technical level',
    'in reserve',
    'accepted for Sandbox',
    'Sandbox completed',
    "candidate's refusal",
  ],
  select: [
    'the application is accepted',
    'refusal by the level of English',
    'refusal by location',
    "recruiter's interview is scheduled",
    'interview of the interviewer is scheduled',
    'questionable',
    'failure on the technical level',
    'in reserve',
    'accepted for Sandbox',
    'Sandbox completed',
    "candidate's refusal",
  ],
};
export const englishLevels = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
export const countries = [
  'Belarus',
  'Georgia',
  'Hungary',
  'India',
  'Lithuania',
  'Moldova',
  'Poland',
  'Russia',
  'Ukraine',
  'United States',
  'Uzbekistan',
];
