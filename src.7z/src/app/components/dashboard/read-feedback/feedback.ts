// export interface Feedback {
//   id: number;
//   candidateId: number;
//   text: string;
// }

export interface Feedback {
  id: 1;
  candidateId: 1;
  fromRecruiter: string;
  fromInterviewer: string;
  fromMentor: string;
  fromInterviewerTwo: string;
}
