
export interface Date_Elements {
  date: string ;
  desc: string ;
}
