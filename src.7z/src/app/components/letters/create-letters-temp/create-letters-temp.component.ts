import { Component } from '@angular/core';

@Component({
  selector: 'app-create-letters-temp',
  templateUrl: './create-letters-temp.component.html',
  styleUrls: ['./create-letters-temp.component.scss']
})
export class CreateLettersTempComponent  {

  constructor() { }

}
