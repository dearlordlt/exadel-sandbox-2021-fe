export interface EducationalProgram {
  name: string;
  acceptanceFrom: string;
  acceptanceTo: string;
  programFrom: string;
  programTo: string;
}
